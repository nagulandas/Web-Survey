import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Clock, Users, BarChart3, ExternalLink } from "lucide-react"

export default function SurveysPage() {
  // In a real app, this would come from MongoDB
  const surveys = [
    {
      id: "1",
      title: "Customer Satisfaction",
      description: "Gather feedback about our customer service",
      responses: 124,
      created: "2 days ago",
      status: "active",
    },
    {
      id: "2",
      title: "Product Feedback",
      description: "Collect insights about our new product features",
      responses: 89,
      created: "1 week ago",
      status: "active",
    },
    {
      id: "3",
      title: "Employee Engagement",
      description: "Annual employee satisfaction survey",
      responses: 45,
      created: "3 days ago",
      status: "draft",
    },
    {
      id: "4",
      title: "Website Usability",
      description: "Evaluate the user experience of our website",
      responses: 210,
      created: "2 weeks ago",
      status: "closed",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Surveys</h1>
        <Button asChild>
          <Link href="/surveys/create">Create Survey</Link>
        </Button>
      </div>

      <div className="flex w-full max-w-sm items-center space-x-2 mb-6">
        <Input type="text" placeholder="Search surveys..." />
        <Button type="submit">Search</Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Surveys</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="draft">Drafts</TabsTrigger>
          <TabsTrigger value="closed">Closed</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {surveys.map((survey) => (
              <Card key={survey.id}>
                <CardHeader>
                  <CardTitle>{survey.title}</CardTitle>
                  <CardDescription>{survey.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Users className="mr-1 h-4 w-4" />
                      <span>{survey.responses} responses</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="mr-1 h-4 w-4" />
                      <span>{survey.created}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" asChild>
                    <Link href={`/surveys/${survey.id}`}>
                      View <ExternalLink className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href={`/surveys/${survey.id}/results`}>
                      Results <BarChart3 className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="active" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {surveys
              .filter((s) => s.status === "active")
              .map((survey) => (
                <Card key={survey.id}>
                  <CardHeader>
                    <CardTitle>{survey.title}</CardTitle>
                    <CardDescription>{survey.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Users className="mr-1 h-4 w-4" />
                        <span>{survey.responses} responses</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4" />
                        <span>{survey.created}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" asChild>
                      <Link href={`/surveys/${survey.id}`}>
                        View <ExternalLink className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link href={`/surveys/${survey.id}/results`}>
                        Results <BarChart3 className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        {/* Similar content for other tabs */}
      </Tabs>
    </div>
  )
}
