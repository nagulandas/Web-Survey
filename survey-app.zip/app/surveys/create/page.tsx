"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Plus, Trash2, MoveDown, MoveUp, Save, Eye } from "lucide-react"
import { useRouter } from "next/navigation"

type QuestionType = "text" | "multipleChoice" | "checkbox" | "rating" | "dropdown"

interface Question {
  id: string
  type: QuestionType
  title: string
  required: boolean
  options?: string[]
}

export default function CreateSurveyPage() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: "q1",
      type: "text",
      title: "What is your name?",
      required: true,
    },
  ])

  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q${questions.length + 1}`,
      type: "text",
      title: "",
      required: false,
    }
    setQuestions([...questions, newQuestion])
  }

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter((q) => q.id !== id))
  }

  const updateQuestion = (id: string, data: Partial<Question>) => {
    setQuestions(questions.map((q) => (q.id === id ? { ...q, ...data } : q)))
  }

  const moveQuestion = (id: string, direction: "up" | "down") => {
    const index = questions.findIndex((q) => q.id === id)
    if ((direction === "up" && index === 0) || (direction === "down" && index === questions.length - 1)) {
      return
    }

    const newQuestions = [...questions]
    const newIndex = direction === "up" ? index - 1 : index + 1
    const temp = newQuestions[index]
    newQuestions[index] = newQuestions[newIndex]
    newQuestions[newIndex] = temp
    setQuestions(newQuestions)
  }

  const addOption = (questionId: string) => {
    const question = questions.find((q) => q.id === questionId)
    if (!question) return

    const options = question.options || []
    updateQuestion(questionId, {
      options: [...options, `Option ${options.length + 1}`],
    })
  }

  const updateOption = (questionId: string, index: number, value: string) => {
    const question = questions.find((q) => q.id === questionId)
    if (!question || !question.options) return

    const newOptions = [...question.options]
    newOptions[index] = value
    updateQuestion(questionId, { options: newOptions })
  }

  const removeOption = (questionId: string, index: number) => {
    const question = questions.find((q) => q.id === questionId)
    if (!question || !question.options) return

    const newOptions = [...question.options]
    newOptions.splice(index, 1)
    updateQuestion(questionId, { options: newOptions })
  }

  const handleSave = async () => {
    // In a real app, this would save to MongoDB
    console.log({ title, description, questions })

    // Simulate saving
    setTimeout(() => {
      router.push("/surveys")
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Create Survey</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.push("/surveys")}>
            Cancel
          </Button>
          <Button variant="outline">
            <Eye className="mr-2 h-4 w-4" /> Preview
          </Button>
          <Button onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" /> Save Survey
          </Button>
        </div>
      </div>

      <Tabs defaultValue="questions" className="w-full">
        <TabsList>
          <TabsTrigger value="questions">Questions</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="share">Share</TabsTrigger>
        </TabsList>

        <TabsContent value="questions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Survey Details</CardTitle>
              <CardDescription>Set the title and description for your survey</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter survey title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter survey description"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {questions.map((question, index) => (
            <Card key={question.id}>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">Question {index + 1}</CardTitle>
                  <CardDescription>
                    {question.type.charAt(0).toUpperCase() + question.type.slice(1)} question
                  </CardDescription>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => moveQuestion(question.id, "up")}
                    disabled={index === 0}
                  >
                    <MoveUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => moveQuestion(question.id, "down")}
                    disabled={index === questions.length - 1}
                  >
                    <MoveDown className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => removeQuestion(question.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor={`question-${question.id}`}>Question</Label>
                  <Input
                    id={`question-${question.id}`}
                    value={question.title}
                    onChange={(e) => updateQuestion(question.id, { title: e.target.value })}
                    placeholder="Enter your question"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor={`type-${question.id}`}>Question Type</Label>
                  <Select
                    value={question.type}
                    onValueChange={(value) =>
                      updateQuestion(question.id, {
                        type: value as QuestionType,
                        options:
                          ["multipleChoice", "checkbox", "dropdown"].includes(value) && !question.options
                            ? ["Option 1"]
                            : question.options,
                      })
                    }
                  >
                    <SelectTrigger id={`type-${question.id}`}>
                      <SelectValue placeholder="Select question type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Text</SelectItem>
                      <SelectItem value="multipleChoice">Multiple Choice</SelectItem>
                      <SelectItem value="checkbox">Checkbox</SelectItem>
                      <SelectItem value="rating">Rating</SelectItem>
                      <SelectItem value="dropdown">Dropdown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {["multipleChoice", "checkbox", "dropdown"].includes(question.type) && (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label>Options</Label>
                      <Button variant="outline" size="sm" onClick={() => addOption(question.id)}>
                        <Plus className="mr-2 h-4 w-4" /> Add Option
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {question.options?.map((option, optionIndex) => (
                        <div key={optionIndex} className="flex gap-2">
                          <Input
                            value={option}
                            onChange={(e) => updateOption(question.id, optionIndex, e.target.value)}
                            placeholder={`Option ${optionIndex + 1}`}
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeOption(question.id, optionIndex)}
                            disabled={question.options?.length === 1}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <Switch
                    id={`required-${question.id}`}
                    checked={question.required}
                    onCheckedChange={(checked) => updateQuestion(question.id, { required: checked })}
                  />
                  <Label htmlFor={`required-${question.id}`}>Required</Label>
                </div>
              </CardContent>
            </Card>
          ))}

          <Button onClick={addQuestion} className="w-full">
            <Plus className="mr-2 h-4 w-4" /> Add Question
          </Button>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Survey Settings</CardTitle>
              <CardDescription>Configure additional settings for your survey</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="collect-emails" />
                <Label htmlFor="collect-emails">Collect email addresses</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="one-response" />
                <Label htmlFor="one-response">Limit to one response per person</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="show-progress" defaultChecked />
                <Label htmlFor="show-progress">Show progress bar</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="shuffle-questions" />
                <Label htmlFor="shuffle-questions">Shuffle question order</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmation-message">Confirmation Message</Label>
                <Textarea id="confirmation-message" placeholder="Thank you for completing the survey!" rows={3} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="share">
          <Card>
            <CardHeader>
              <CardTitle>Share Survey</CardTitle>
              <CardDescription>Configure sharing options for your survey</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="survey-link">Survey Link</Label>
                <div className="flex gap-2">
                  <Input id="survey-link" value="https://survey-tool.com/s/abc123" readOnly />
                  <Button variant="outline">Copy</Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Collaborators</Label>
                <div className="border rounded-md p-4">
                  <p className="text-sm text-muted-foreground mb-4">Add team members to collaborate on this survey</p>
                  <div className="flex gap-2">
                    <Input placeholder="Enter email address" />
                    <Select defaultValue="edit">
                      <SelectTrigger className="w-[120px]">
                        <SelectValue placeholder="Permission" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="view">Can view</SelectItem>
                        <SelectItem value="edit">Can edit</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button>Invite</Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Privacy Settings</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="public-results" />
                    <Label htmlFor="public-results">Make results public</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="password-protect" />
                    <Label htmlFor="password-protect">Password protect</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
