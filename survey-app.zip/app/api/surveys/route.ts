import { NextResponse } from "next/server"

// GET /api/surveys - Get all surveys
export async function GET(request: Request) {
  try {
    // In a real app, this would query MongoDB
    // const { db } = await connectToDatabase()
    // const surveys = await db.collection('surveys').find({}).toArray()

    // Mock data for example
    const surveys = [
      {
        _id: "1",
        title: "Customer Satisfaction",
        description: "Gather feedback about our customer service",
        status: "active",
        createdAt: new Date("2023-04-15"),
        responses: 124,
      },
      {
        _id: "2",
        title: "Product Feedback",
        description: "Collect insights about our new product features",
        status: "active",
        createdAt: new Date("2023-04-10"),
        responses: 89,
      },
    ]

    return NextResponse.json(surveys)
  } catch (error) {
    console.error("Error fetching surveys:", error)
    return NextResponse.json({ error: "Failed to fetch surveys" }, { status: 500 })
  }
}

// POST /api/surveys - Create a new survey
export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate the request body
    if (!body.title || !body.questions || !Array.isArray(body.questions)) {
      return NextResponse.json({ error: "Invalid survey data" }, { status: 400 })
    }

    // In a real app, this would insert into MongoDB
    // const { db } = await connectToDatabase()
    // const result = await db.collection('surveys').insertOne({
    //   ...body,
    //   createdAt: new Date(),
    //   updatedAt: new Date(),
    //   status: 'draft'
    // })

    // Mock response
    const newSurvey = {
      _id: Date.now().toString(),
      ...body,
      createdAt: new Date(),
      updatedAt: new Date(),
      status: "draft",
    }

    return NextResponse.json(newSurvey, { status: 201 })
  } catch (error) {
    console.error("Error creating survey:", error)
    return NextResponse.json({ error: "Failed to create survey" }, { status: 500 })
  }
}
