import { NextResponse } from "next/server"

// GET /api/responses/[surveyId] - Get responses for a survey
export async function GET(request: Request, { params }: { params: { surveyId: string } }) {
  try {
    const surveyId = params.surveyId

    // In a real app, this would query MongoDB
    // const { db } = await connectToDatabase()
    // const responses = await db.collection('responses')
    //   .find({ surveyId })
    //   .toArray()

    // Mock data for example
    const responses = Array.from({ length: 10 }, (_, i) => ({
      _id: `resp${i + 1}`,
      surveyId,
      respondentEmail: i % 2 === 0 ? `user${i}@example.com` : undefined,
      answers: [
        { questionId: "q1", value: `Respondent ${i + 1}` },
        { questionId: "q2", value: ["Good", "Excellent"][i % 2] },
      ],
      completedAt: new Date(Date.now() - i * 86400000), // days ago
    }))

    return NextResponse.json(responses)
  } catch (error) {
    console.error("Error fetching responses:", error)
    return NextResponse.json({ error: "Failed to fetch responses" }, { status: 500 })
  }
}
