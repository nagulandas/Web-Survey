import { NextResponse } from "next/server"

// POST /api/responses - Submit a survey response
export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate the request body
    if (!body.surveyId || !body.answers || !Array.isArray(body.answers)) {
      return NextResponse.json({ error: "Invalid response data" }, { status: 400 })
    }

    // In a real app, this would insert into MongoDB
    // const { db } = await connectToDatabase()
    // const result = await db.collection('responses').insertOne({
    //   ...body,
    //   completedAt: new Date(),
    //   ipAddress: request.headers.get('x-forwarded-for') || 'unknown'
    // })

    // Mock response
    const newResponse = {
      _id: Date.now().toString(),
      ...body,
      completedAt: new Date(),
    }

    return NextResponse.json(newResponse, { status: 201 })
  } catch (error) {
    console.error("Error submitting response:", error)
    return NextResponse.json({ error: "Failed to submit response" }, { status: 500 })
  }
}
