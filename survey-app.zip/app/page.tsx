import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, BarChart3, Users, FileText } from "lucide-react"

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="py-12 md:py-24 lg:py-32 flex flex-col items-center text-center">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6">Create, Share, and Analyze Surveys</h1>
        <p className="text-xl text-muted-foreground max-w-[800px] mb-8">
          A collaborative platform for creating surveys, collecting responses, and analyzing data.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button asChild size="lg">
            <Link href="/surveys/create">
              Create Survey <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/surveys">Browse Surveys</Link>
          </Button>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <FileText className="h-10 w-10 mb-2 text-primary" />
            <CardTitle>Create Surveys</CardTitle>
            <CardDescription>Build custom surveys with multiple question types</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Create surveys with various question types including multiple choice, text, rating scales, and more.</p>
          </CardContent>
          <CardFooter>
            <Button asChild variant="ghost">
              <Link href="/surveys/create">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <Users className="h-10 w-10 mb-2 text-primary" />
            <CardTitle>Collaborate</CardTitle>
            <CardDescription>Work together with your team</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Share surveys with team members, assign roles, and collaborate on survey creation and analysis.</p>
          </CardContent>
          <CardFooter>
            <Button asChild variant="ghost">
              <Link href="/dashboard">
                View Dashboard <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <BarChart3 className="h-10 w-10 mb-2 text-primary" />
            <CardTitle>Analyze Results</CardTitle>
            <CardDescription>Get insights from your survey data</CardDescription>
          </CardHeader>
          <CardContent>
            <p>View responses, generate reports, and analyze survey data with visual charts and statistics.</p>
          </CardContent>
          <CardFooter>
            <Button asChild variant="ghost">
              <Link href="/dashboard">
                View Analytics <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </section>
    </div>
  )
}
