"use client"

export function BarChart() {
  return (
    <div className="w-full h-[300px] flex items-center justify-center bg-muted/20 rounded-md">
      <p className="text-muted-foreground">Bar chart would render here</p>
    </div>
  )
}

export function LineChart() {
  return (
    <div className="w-full h-[300px] flex items-center justify-center bg-muted/20 rounded-md">
      <p className="text-muted-foreground">Line chart would render here</p>
    </div>
  )
}
